CREATE TABLE employee (
    employeeID VARCHAR(40) PRIMARY KEY,
);